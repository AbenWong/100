## state

- v（尤指明清楚谨慎地）声称，宣称，声明 state regulators 州政府管理者
- n政府，国家，州；状态，情况
- adj国有的，国家的 
  understate
- v轻描淡写地叙述；淡化（某事的重要性或者严重性） 
  overstate
- 把。。。。讲得过分；夸大，夸张 
## declare
- v公布，宣布；宣称（...为事实），表明（态度，意图等）
- 申报（应纳税物品、收入等） discrimination歧视 
  As Jane Austen said in Pride and Prejudice,I declare after all there is no enjoyment like reading. 
 ## claim
- v自称，声称，断言（未经证明或可能错误的事）；要求（拥有），认领；索取，索（款）；（战争、事故等）夺去（声明）
- n声称，说法；（根据权利而提出的）要求，索赔；（对某事物的）权利，所有权 
  despite some claims to the contrary 
  proclaim
- v（正式）宣告，声明；表明，明确显示 
 ## pronounce
- v发音，读（音）；正式宣布（或公布）
- enounce v声明
- enunciate v（清晰仔细地）发（音）；念（字）；（清楚准确地）阐明，阐述
- articulate v口齿清楚地讲（话）；清晰发（音）；清楚地表达 adj能说会道的；（文章、说话）明晰的，清楚的
- announce v宣布，宣告；通知，告知；郑重地说 
## assert
- v断言，坚称；维护（权利或者权威）；坚持（主张）
- assertion
- assertive 
##  affirm
- v肯定属实，申明，断言 
 ## allege
- v断言，声称
- allegation
- alleged adj声称的；被断言的；涉嫌的
- allegiance n忠诚，效忠，拥戴 
  扩展：so-called adj所谓的；号称的 supposed adj据说的，所谓的 
##  condition
- n状况，状态；处境；条件，条款；前提；疾病；健康状况；【～s】环境，条件
- v使习惯于，使适应；养护（头发等）
- conditional
- conditioner 护发素 ，hair conditioner
- air conditioning 
 ## change
- v改变，更改；转换，更换，替换；兑换；换乘
- n变化，变更，变革；硬币，零钱 
  climate change 
  扩展 exchange v交换；兑换；交流；互访 n短暂的交谈；交流，互访 
 ## move
- v移动；改变；采取行动；搬家；影响；感动；提议
- n移动；改变；步骤；行动，举措 
  to back rush radical moves 
  boil down to：归根结底 
 ## shift
- v转移，移动；转移；转变，改变（意见等）；推卸
- n转变；轮班；轮班职工 
##  switch
- v打开，关闭；改变，转变；转换（职业，政策、生活方式）；交换
- n开关；彻底改变 
 ## transition
- v转变，过度
- n转变，过度；变革，变迁 
 ## transfrom
- v使彻底改变（变得更好）；改变；使改观 
  派生 transformer transformation 
  扩展 transform sb/sth from sth) into sth 
  a reformed criminal 一名改过自新的罪犯 
 ## alter
- v(尤指以相对细微但却显著的方式)改变（性质或成分）；修改（使衣服更合身） 
  派生 alteration alternate alternation alternative 
 ## modify
- v（略微地）修改，更改，改进；改造；修饰，限定 
  派生modification modifier 
 ## convert
- v（是形态、性质、功能）改变；改变（观点、原则或做事方式）；改建，改造；换算；（使）改变信仰
- n改变信仰者 
  to convert our lives to data 
  派生 conversion convertible 
 ## transfer
- v（使）转移；（使调职；转移（感情）；传染（疾病）；转让（权利等）；换乘，换乘 
  派生 transference 
 ## transplant
- n(器官)移植
- v移植；移栽；（使）移居 
 ## plant
- n植物；工厂；发电厂
- v播（种）；种植；放置，使固定 
##  rule
- v统治，管理，控制；判决，裁定‘
- n（游戏、公司或学校的）规则，章程，规定；定律；习惯，常规；统治，管辖 
  派生 ruling裁决，判决 ruler统治阶级 
  administer =[administrate]
- v管理；治理；施行，执行 
  派生 administration 
  补充minister n部长，大臣 prime minister首相 
##  dominate
- v控制，支配，统治，主导；俯视，高耸于 
  派生 dominant 
##  govern
- v统治，管理，治理；支配，影响 
##  reign
- v统治，当政；占优势；盛行
- n君主统治时期；任期 
##  regulate
- v（尤其通过规章）控制，管理；调整，调节 
 ## code
- n法规，法典；道德准则，行为规范；密码，代码；邮编，区号
- v把.....编码 
  law
- n法律；规则；定律；规律 
  派生lawful lawyer 
 ## statute
- n法令，法规；条例；章程 
 ## bill
- n账单，议案，法案；纸币，钞票；广告，海报
- v宣传；给....开账单 
 ## effect
- n影响，结果；效果，作用；感受
- v使发生，实现 
  派生effective. efficient高效 
 ## result
- n结果，后果；效果；考试成绩，业绩
- v（因。。。发生）；
- 派生 resultant 
 ## consequence
- n结果，后果，影响；重要性
- 派生consequent ,consequently因此 
 ## outcome
- n结果，结局，后果 
 ## firm
- adj坚固的，结实的，强有力的；坚决的，坚定的；确凿的；坚挺的，稳定的
- adv坚定地；坚决地
- n(小型的)公司，商行，事务所
- v使坚固；坚挺，稳步上涨 
##  solid
- adj固体的，坚硬的;实心的；结实的，坚固的；可靠的，确凿的；连续的，不间断的
- 派生solidity solidify solidarity 
 ## tight
- adj牢固的，紧的；紧身的；严密的，严格的；亲密的；小气的；吝啬
- adv紧紧地，牢固地
- 派生tighten 
 ## corporation
- n大公司，企业；法人；法人团体 
  venture
- n风险企业；投机活动
- v敢于冒险，敢做；冒昧地说，谨慎地做
- venture capital 风险资本 joint-venture合资企业 
 ## enterprise
- n公司，企业；事业；进取心，事业心，创业精神 
  be comprised of 由什么组成
- 派生 enterprising entrepreneur entrepreneurial 
##  include
- v包括，包含；列入
- 派生inclusive ~ness 
##  incorporate
- v纳入，并入；包含，包括；注册成立 
 ## cover
- v覆盖；包括，涉及；报道，发表；（钱）足够支付；给。。。上保险；掩盖
- n覆盖物，遮盖物；书封；藏身处。掩护物；承保范围 
 ## increase
- v（使）增长，增多，增加
- n增长；增多；增加
- 派生 increasingly 
 ## raise
- v举起，增加，提高；起身；募集；引起；导致；激起；提出；抚养，养育；饲养
- n加薪，提薪 
 ## rise
- v上升；增加，提高；增强；站起来，起床；变得更加成功；起义，反抗；矗立，耸立
- n增长，提高；兴起；加薪 
  to rise above temptation跨过诱惑=抵挡诱惑 
##  expand
- v扩大，扩充；增强，增加；扩展（业务） 
  to expand the orchestra's repertoire 
  派生expansion 
##  multiply
- v 乘，使相乘；成倍增加，迅速增加；繁殖，滋生 
##  accumulate
- v积累，积聚；（数量）逐渐增加
- 派生 accumulation accumulative 
##  swell
- v(使)膨胀，肿胀；（使）增加，增大，扩大 
  to swell by 11% every year since 2000 
##  escalate
- v（使）（战斗，暴力事件或不好的情况）升级，（使）恶化；（使）升高，（使）增加 
##  suggest
- v提议，建议；推荐，举荐；暗示，表明；使人想到 
  a new study suggests that…… 
  派生 suggestion suggestive 
##  recommend
- v推荐，举荐；劝告，建议 
##  propose
- v（尤指在会议上）正式提议；打算，计划；提名；提出……供表决；求婚 
 ## advice
- v(经济或知识丰富者)劝告，忠告；建议；通知，正式告知
- 派生 advice advisor advisory advisable 
 ## indicate
- v表明，显示；强烈暗示；指示；表示，注明 
  派生indication indicative indicator 
 ## imply
- v意指，暗指，暗示；意味着（某事可能是真的）；必然包含，使有必要 
  as its name implies 
  派生implication 
 ## manifest
- v清楚显示，表明（尤指情感、态度或品质）
- adj明显的；显而易见的 
  manifesto宣言. communist manifesto共产党宣言 
 ## hint
- v暗示，示意
- n暗示，提示；征兆，迹象；少许，少量；秘诀，窍门 
 ## allow
- v允许，准许；使能够，促使；听凭，任由；承认，同意；留出，给予（足够的时间） 
  派生allowance 
##  permit
- v允许，许可；（事件、条件、情况等）使有可能；特许证 
  permission permissible permissive 
 ## approve
- v赞成，同意；批准，通过（计划，要求等） 
  to approve a patent 
  派生approval 
 ## authorize
- v授权，批准，许可 
 ## license
- v批准，许可
- n许可证，执照；许可，准许；诱因，借口 
##  entitle
- v使有权利，使有资格；给……名（或题名） 
  be entitled to more freedom 
 ## value
- n价值，价值观，道德标准；用途，积极作用
- v给……估价；重视，珍视 
  派生valuable 
 ## worth
- n价值；意义；作用
- adj有……价值的，值……钱的；值得的，有价值的 
  派生worthless worthy 
 ## principle
- n道德原则，行为准则；法则，原则；原理；观念；（行动、思想）理由，信条 
 ## moral
- n寓意；道德，品行
- adj道德的，品行端正的；有道德的 
  the death of moral purpose 
  派生 morality 
##  ethic
- n伦理标准；道德原则；伦理，伦理学 
  派生 ethical adj道德的；伦理的，合乎道德的 
##  integrity
- n正直，诚实，诚信；完美，完整 
 ## conscience
- n良心，良知；内疚，愧疚；道德心 
  派生 conscientious 
 ## appreciate
- v欣赏，赏识；重视；理解，明白；感激 
  派生 appreciation 
 ## cherish
- v珍惜；珍视，爱护；抱有（希望），怀念
