## giggle

* v 咯咯的笑，傻笑
* n 咯咯笑，傻笑；趣事，好玩的事

## chuckle

* v 窃笑，暗自发笑

## snigger

* v 暗笑，窃笑

## grin

* v/n 露齿笑，咧嘴笑

## laugh

* v 笑，大笑；嘲笑，讥笑
* laughter n笑；笑声

## glance

* v 瞥，看一眼；浏览
* n 一瞥，扫视

## peep

* v 窥视，瞥，偷看

## peek

* v 瞥，匆匆一眼；偷看，窥视
* n 一瞥，偷窥一眼 

## glimpse

* v 瞥见，看一眼；开始理解

* n一瞥，瞟一眼，扫视；短暂的感受

## skim

* v撇去；掠过，擦过，滑过；略读，浏览

## scan

* v 细看，绅视，查找；粗略地看，浏览；扫描
* n 扫描检查；浏览，快速查阅
* scanner n扫描仪，扫描器

## browse

* v 浏览，随意翻阅；随便看；吃草

## grateful

* adj 感激的，感谢的

## appreciative

* adj 有鉴赏力的，欣赏的；感激的

## greet

* v问候，致意，向……打招呼；迎接；回应，对（某事）作出反应
* censor v审查   n审查员
* censorship 审查制度
* greeting n 问候，招呼；[-s]祝词，问候语

## salute

* v 向……致敬；赞扬，颂扬
* n 敬礼；致意，致敬；举枪礼；颂扬
* salutation n问候，致意；称呼语

## hail

* v赞扬，把……誉为；呼喊，招呼；下冰雹

## hostage

* n人质
* be hostile to 
* hostility
* hospitality

## captive

* adj 被监禁的，被关押的；不得不看的，无权选择的；被垄断的
* n 囚徒，俘虏，战俘

## immune

* adj 有免疫力的，不受影响的；豁免的，免除的
* immunity n免疫力；免除
* immunize v 使免疫

## exempt

* adj 被免除的，被豁免的
* v 免除，豁免
* exemption n免税额，可免税部分；免除，豁免

## inhabit

* v 居住于，栖居于；
* inhabitant n 居民，住户；栖息动物

## reside

* v 居住，定居
* resident n居民；住户 adj 居住的；定居的
* residential adj 居住的；住宅区的；寄宿制的

## dwell

* v 居住，生活
* dweller n 居民
* dwelling n住宅

## inhale

* v 吸气；吸入

## breathe

* v 呼吸；呼气，喷出

## gasp

* n 喘息；倒抽气
* v 大声吸气，倒抽气；急促呼吸

## respire

* v 呼吸
* respiration n 呼吸

## interim

* adj 暂时的，临时的；过渡期间的
* n 间歇，期间；过渡时期

## temporary

* adj 暂时的，短暂的，短期的
* n 临时雇员，零时工

## transient

* adj 短暂的，转瞬即逝的；流动性的，临时的
* n 临时工；游民，流浪者

## provisional

* adj 临时的，暂时性的，暂定的

## interval

* n 间隔，间歇；中场休息

## interrupt

* v 打断，打扰；中止，阻碍；使……暂停

## disrupt

* v 使中断；扰乱，使混乱
* disruptive adj 破坏性的；制造混乱的
* disruption n 中断；扰乱；混乱

## interfere

* v 扰乱，干扰；阻碍，妨碍；参与，插手，干涉
* interference n 干预，干涉；扰乱，干扰

## intervene

* v 干预，介入，插手；阻碍，中断；打岔，插话；介于……之间
* intervention n 干涉，干预

## intimidate

* v 恐吓，威胁；使害怕，使失去信心
* intimidation n 恐吓，威胁
* intimidating adj可怕的，令人胆怯的

## threaten

* v 威胁，恐吓；危及；可能发生，可能引起
* threatening adj 有威胁性的，危险的

## menace

* n威胁，恐吓；危险的人
* v 危及；威胁，恐吓

## blackmail

* n/v 勒索，敲诈；胁迫，要挟

## jog

* v慢跑；轻碰，轻推
* jogger n 慢跑锻炼者
* jogging n 慢跑

##  trot

* v 快步走，小步跑
* n 小跑；慢跑，小步跑

## junior

* adj 级别低的，初级的；青少年组的，三年级的
* n 职位较低；青少年；三年级学生

## subordinate

* n 下级，部署 adj 次要的；隶属的，下级的
* v 使从属于
* subordination n次要；下属

## inferior

* adj 差的，次的；低级别的，下级的
* n 下级，下属
* inferiority n低等的，劣等

## knit

* v/n 编织，针织；紧密结合；使团结，使联合；愈合

## weave

* v 编，织，编制；迂回进行，穿行；编造，编撰
* n 织法，编织样式
* weaver n 编布工；编织者

## knot

* n 结，疙瘩；发簪；筋挛；问题，麻烦
* v 把……打成结；筋挛
* knotty adj复杂的，难以解决的

## intertwine

* v 密切关联；缠绕，交织在一起

## mild

* adj 温和的；不严重的，不强烈的，轻微的；温暖的
* mildly adv略微地，有点儿；和善地，委婉地

## gentle

* adj 文静地，温和的，和蔼的，轻柔的，平缓的
* gently adv 轻柔地，温和地，平缓地
* gentleman n先生，绅士，君子；有身份的人，富绅

## tender

* adj 嫩的，柔的；温柔的，慈爱的；娇嫩的
* v 递呈，呈交；提出

## meek

* adj 温顺的，驯服的，顺从的

## lenient

* adj 仁慈的，宽容的；温和的
* lenience n 仁慈，宽大

## mortal

* adj 不能用生的，终有一死的；凡人的，世俗的；极其严重的，致命的
* n 平凡百姓，普通人；人，凡人
* mortality n 死亡人数；死亡率；必死性，生命的有限

## fatal

* adj 致命的，灾难性的，毁灭性的
* fatal flaw
* fatality n 死亡；致命性；宿命

## deadly

* adj 致命的，致死的；不共戴天的；完全的，全部的

## malignant

* adj 恶性的，致命的；恶意的，恶毒的

## lethal

* adj 致命的，致死的，具有杀伤力的；危险的，要命的

## folk

* adj 大众的，民间的，民俗的
* n 人们；[-s]家人，家属；民谣，民间音乐

## murmur

* v 低声说，悄声说；咕哝，抱怨；发出轻声
* n 低语；咕哝，嘟囔；轻声

## whisper

* v 低语，小声说；耳语
* v 低语，小声说话，耳语；传闻，谣言

## mutter

* v 咕哝，嘀咕；轻声说话；私下抱怨，小声质疑

## rustle

* v 发出沙沙声；沙沙作响
* n 沙沙声，簌簌声

## mutual

* adj （尊重、情感）相互的，彼此的；共同的，共有的；意见一致的

## reciprocal

* adj 互相的，相互的；互惠的，互相补偿的

## communal

* adj 群体的，社区的；公共的，公用的，共有的

## myth

* n 神话；错误见解；荒诞说法
* mythical adj 神话的；虚构的，杜撰的
* mythology n 神话；神话故事

## legend

* n 传说，传奇；传奇人物
* legendary adj 非常著名的，大名鼎鼎的；传说的，传奇的

## fable

* n 寓言，神话传说；谣传，无稽之谈

## superstition

* n 迷信，迷信观念
* superstitious adj 迷信的，盲目的

## nuts

* adj 发疯的，发狂的；狂热的，执着的

## insane

* adj 精神错乱的；疯狂的；荒唐的
* insanity n 精神错乱；疯狂；极端的愚蠢（行为），荒唐（事）

## mad

* adj 疯的；非常愚蠢的；非常恼火的，狂怒的；着迷的；发狂的
* madden v 使极为恼火，使狂怒

## irrational

* adj 不合逻辑的，不合理的；不理性的，荒谬的

## packet

* n (装商品的)小包，小盒，小袋；小包裹

## parcel

* n 包裹，邮包；一块，一片
* v 包起来
* parcel sth out 把……分发出去，分配

## carton

* n塑料盒，硬纸盒；包装箱

## pat

* v/n 轻拍，轻敲

## tap

* v 轻拍，轻叩，轻敲；打节拍；打开水龙头；开发，利用；窃听
* n 轻敲，龙头，阀门；窃听器

## stroke

* v 轻抚，抚摸，轻触；击（球）
* n 敲，打，击；中风；一笔；泳姿；轻抚，抚摸；一件事；突发

## caress

* v 爱抚，抚摸；轻触，轻拍
* n 爱抚，抚摸；亲吻

## touch

* v 触摸，碰；感动，触动；涉及，触及，对……有影响
* n 触摸，碰；触觉，触感；手法，风格，特色，特长；少许，一点儿

## pave

* v 铺，铺彻，铺筑
* pavement n 人行道，路面

## tile

* v 普瓦于，贴地砖于
* n 瓷砖，墙砖，地砖；瓦片

## pilot

* n 飞行员，领航员；试验性的方案；电视试播节目
* v 驾驶；试验，试行；带领，引领
* adj 试验性的，试点的，小规模的

## navigate

* v 领航，导航；在……上航航；理解，应付；浏览
* navigation n航行，航海，航运

## steer

* v 驾驶；引导，指导；引领

## trial

* n 审讯，审判；试验，试用
* v 测试，实验，试用

## pipe

* n 管，管道；烟斗；笛子，管乐器
* v 用管子输送；用电缆传送；吹笛子

## tube

* n 管子；地铁；电视机

## canal

* n 运河，水道，沟渠；（动植物体内）管，道
* anus 肛门  ， trench 沟渠，战壕， channel 水渠，频道，通道

## plateau

* n 高原；稳定期，停滞时期
* plain n  平原    a 朴实的，简单的

## highland

* n 高地，高原；山区
* adj 高地的，高原的

