## consider

- v认为，把……什么看作；考虑，细想；体谅，考虑到；顾及 
  considerable considerate consideration considering 
##  suppose
- v认为，推断，料想；假定，设想 
  be supposed to serve as helpful advisors 
  supposition supposed supposedly 
##  deem
- v认为，视为；相信 
##  regard
- v认为，把……看作；（尤指以某种方法）注视，凝视
- n尊重，尊敬；注意，关注，关心；～s 问候，致意 
  regarding~concerning regardless(be regardless of与什么无关) 
##  reckon
- v想，认为；料想，预计；估算，计算 
##  contemplate
- v打算，想，考虑；深思熟虑；苦思冥想；端详，凝视 
##  meditate
- v沉思，深思；默想，冥想；考虑，谋划 
  meditation n冥想 
##  ponder
- v仔细考虑，深思（about/on/over） 
  this rainy evening the wind is restless.I look at the swaying branches and ponder over the greathness of all things. --Stray Birds,Tagore(泰戈尔《飞鸟集》) 
##  reason
- n原因，理由；道理，情理；理智，思考力，理解力
- v推理，推断；思考，判断 
  within reason 
##  ground
- n地面，土地；场地；范围，领域；观点，立场；～s 充分的理由，根据 
  groundless grounding 
##  argument
- n争论，争吵，争辩；理由，论据 
  to provide arguments both for and against monarchy 
  argumentation argumentative 
##  justification
- n(做似乎错误的事情的)正当理由，合理的解释（for） 
##  logic
- n逻辑，思维方式；（做某事的）道理，合乎情理的原因；逻辑学 
  logical thinking ,logical reasoning 
##  concern
- n担忧；关心，关爱；重要的事情；负责的事；公司，企业
- v担心，使担忧；与……有关，涉及；认为（做某事）重要 
  widespread concern 
  concerning concerned 
##  worry
- v担心，担忧，发愁；烦扰，使不安宁
- n忧虑；令人烦恼的事 
##  anxiety
- n焦虑；担心，忧虑；渴望（for） 
  anxious 
  worryning doesn't take away tomorrow's troubles.It takes away today's peace --unknown 
##  influence
- n影响，作用；支配力，控制力，影响力；有影响的人或物
- v影响，对……起作用；支配，左右 
  influential 
##  impact
- n撞击，冲击；巨大影响，强大作用
- v撞击，冲击；（对某事）有影响，有作用 
##  power
- n控制力，影响力；统治，政权；能力；权力，职权；有影响力的大国
- v给……提供动力，驱动；（使）迅猛移动，快速前进 
  superpower n超级大国；超能力‘ 
##  affect
- v影响；侵袭，使感染；（感情上）深深打动；假装 
  affection感情。 affectation做作 
 ## issue
- v宣布，公布；<正式>发给，共给；发行；出版，发表；向……颁发
- n重要议题，问题，担忧；（报刊的）期、号、版次 
##  affair
- n事件；个人事物；【～s】公共事务；不正当关系 
##  matter
- n事情，问题；物质，材料
- v重要，要紧，有关系 
 ## edition
- n版本；一次印刷量，版次；（报纸、杂志）一份；一期 
##  version
- n变体，变种；（从不同角度的）描述，说法；（电影、剧本、乐曲等）版本，改编形式 
##  publish
- v出版，发行；（在报刊）发表，刊登；（在互联网上）发表 
  to publish stories on newsprint 
  publisher publication 
##  distribute
- v分发，分配；分销；使散开，使分布 
  distribution. distributor 
#  view
- n(个人的)看法，观点，态度；（理解或思维的）方法，方式；景色，风景；视野
- v把……视为，以……看待；查看，观看 
##  perspective
- n(思考问题的)角度，观点，想法；客观判断力，权衡轻重的能力 
##  opinion
- n意见，看法；（对某人的）评价，印象；舆论，（群体的）观点；专家意见 
  to voice their opinions 
 ## outlook
- n观点，见解；前景，可能性；景色，景致，景观 
 ## point
- n观点，见解；要点，重点；意图，目的；具体细节（或事实）；时刻，罐头；地点；得分
- v（用手）指；瞄准；（意思上）指向 
##  viewpoint
- n观点，看法；角度 
 ## standpoint
- n立场，观点 
 ## sight
- n视力；视觉；目睹；视力范围，视野；景象，情景；[the -s]名胜，风景
- v看到，发现（期待的事物） 
##  scene
- n地点，现场；时间，场面，情景；片段，镜头；景象，景色；风景画；圈子，界，坛 
  behind the scenes 
  scenery scenario 
##  landscape
- n风景，景色；形势，情形
- v美化……的环境 
##  panorama
- n全景，远景；概述，概论 
 ## benefit
- n（对人体的）益处，好处；优势；（公司提供的）福利，奖金；（保险公司支付的）保险金
- v对（某人）有用；使收益；得益于 
  beneficial 
##  sake
- n目的，利益；理由，缘故 
  for the sake of 
 ## interest
- n兴趣，爱好；利益；利息；厉害关系；股份；利益团体，同业，同行
- v使感兴趣；使关注 
 ## reward
- n回报，报酬，奖励；赏金
- v奖励，奖赏，给以报酬 
  rewarding 有回报的 
  award 
##  advantage
- n有利条件；优势；好处，优点 
  advantageous有利的 
 ## virtue
- n美德，高尚品德；优秀品质，良好习惯；优点，长处，用处 
  virtuous 
 ## measure
- v测量，度量；估量；衡量，判定（重要性、价值或影响等）
- n（一定的）量，程度；尺度，标准；判断，衡量；措施，办法 
  measurable measurement 
 ## gauge
- v测量；估计，估算；判断，判定 
 ## calculate
- v计算；估计，推测 
 ## compute
- v计算；估算 
  computerize 
 ## count
- v数数，计算；计入，包括；重要，有价值；（被）正式接纳，正式认可；认为，看作 
 ## estimate
- v估算；估价
- n(对数量、成本等的)估计，估价 
 ## judge
- v（认真考虑后）认为，判断，判定，评价；裁判，评判；尤指不公正的方式）做出评价；（在法庭上）审判，审理
- n法官，审判官；裁判员 
  judgment [英式judgement] 
 ## evaluate
- v评价，评估 
 ## acess
- v评估，评定（性质、质量）；估算，核定（数量、价值） 
 ## appraise
- v估量，估价；（对某人的工作）作出评价 
##  means
- n方法，手段；财富，收入 
  by no means/not by any means 绝不，一点都不 
##  method
- n方法，办法，措施；条理，有条不紊 
  methodical methodology 
 ## initiative
- n新措施，倡议；积极性，进取心；【the ~】掌握有利条件的能力（或机会），主动权 
##  appear
- 似乎，看来；出现，问世；出席，露面 
  appearance 
##  seem
- v(涉及推断)好像，似乎，看来 
  However difficult life may seem,there is always something you can you and succeed at.--Stephen Hawkking 
 ## surface
- n表面；外表
- v浮出水面；（隐藏或被掩盖一段时间后）露面，重新出现，显露，被披露 
 ## arrive
- v到达，抵达（at/in）；（新产品或发明）出现，问世；（尤指经过等待或期盼后）来临，到来；作出（决定），得出（结果）（at） 
##  emerge
- v出现，露出；（从困境中摆脱出来），熬出来；显露，暴露；（机构、行业等）兴起 
  emergency literature 
##  loom
- v赫然耸现；显得突出，逼近
- n织布机 
##  average
- n平均数
- adj平均的；平常的，普通的，（数量）中等的，适中的
- v平均为 
 ## mean
- v意味着；意思是；打算，意欲；对某人重要（或有价值）
- adj吝啬的；刻薄的；平均的，介于中间的；（能力或智力）平庸的，一般的
- n平均值，平均数；中间，中庸 
  meaning meaningful 
 ## common
- adj常见的；普通的；共有的，共同的；普通的，寻常的，平凡的 
  plain adj普通的，平凡的 
 ## ordinary
- adj平常的，普通的，平凡的；平庸的，平淡无奇的 
 ## commonplace
- adj常见的；平凡的，普通的
- n平常的事；老生常谈 
 ## regular
- adj规则的，有规律的；定期的，频繁的；通常的，惯常的；均匀的，端正的；持久的，稳定的；普通的，平凡的
- n常客，老顾客 
  regularity 
 ## medium
- adj中等的；中间的，平均的；（颜色）不深不浅的，适中的
- n（表现）方式，（交流）手段；【复数形式media】媒介，媒介物 
  social media 
 ## intermediate
- adj(两状态之间)，中间的；中级的，中等的，适合中等程度者的 
 ## justice
- n公平，正义；合理，正当；司法制度，法律制裁；法官 
  justify 
 ## equity
- n公平，公正；（公司的）资产净值 
  equitable 
 ## legitimacy
- n合法性；合理性，正当性 
  legislation
- n法律，法规 
  law n法律，法律制度，法律体系 
  rule n规则；法规；规章；条例 
  magistrate 
##  provide
- v供给，提供，给予；规定 
  provision provided 
##  supply
- v供应，供给，提供
- n供应量；储备；（军队或探险队等的）补给，补给品；供应，供给 
 ## offer
- v主动给予；提供，供应；提议；出（价）；献祭
- n主动提议，建议；出价，报价；（通常为短期的）处理价，特价 
 ## serve
- v（为……）工作，服务；履行义务，尽职责，任职；可能作；能满足……的需要，提供；上（菜），开（饭） 
  service serving servant 
##  dispense
- v分配，分发；施与，提供（尤指服务）
- dispensable 
##  afford
- v买得起；负担，承担得起（后果）；（有时间）做，能做；给予，提供 
  affordable 
##  render
- v使成为，使变得；给予，提供；递交，提交；表达，翻译 
##  furnish
- v布置家居，供应，提供 
##  survey
- n民意调查，民意检测；测量；勘测；总体研究，概述
- v查看，审视；总体研究，概述；勘测；（对……）做民意调查，进行民意检测 
##  poll
- n民意调查；选举投票；投票数
- 对……进行民意检测 
  pollster 民意调查人 
##  questionnaire
- n调查表；问卷 
##  census
- n（官方的）统计；人口普查，人口调查 
##  overview
- n概观，概述 
##  investigate
- v调查，侦查（某事）；调查（某人）；研究，调查 
  investigation 
##  inquire
- v询问，打听；调查，查究 
  inquiry 
##  interrogate
- v询问，审问，盘问 
##  approach
- v靠近，接近；与……接洽，找……商量；对付，着手处理；邻近
- n通路，道路；方法，方式；靠近，接近 
  approachable 
##  access
- n通道，通路；机会，权利
- v读取信息；到达，进入，使用 
  accessible 
  have access to sth:有……的机会，有……的权利 
##  avenue
- n街道，林荫大道；方法，途径 
##  channel
- n电视台，电视频道；渠道，途径；方式，方法；水渠；海峡
- 为……投资，倾注；输送资金，提供帮助 
##  mode
- n方式；风格，样式；（设备的）模式；（情感或行为的）状态，状况