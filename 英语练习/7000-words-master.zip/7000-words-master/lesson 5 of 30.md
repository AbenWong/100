force

* n力，力量；武力，暴力；部队；军事行动；自然力；（为某目的的组织起来的）一群人；有影响力的事物（或人）；权利，效力；【～s】军队
* v强迫，迫使；用力移动，强行打开；强作（笑颜）
* forceful. adj（人）强有力的；（论据、理由等）有力的，有说服力的；有影响力的；强迫的，使用武力

might

* n力量；威力；能力
* aux 可能，可以；（表示可能性）可能，也许；应该，本该
* mighty adj强大的；巨大的；伟大的

strength

* 体力，力气，力量；（政治、军事或经济上的）实力；毅力，意志力；强烈程度；强度，力度；优点，长处，强项
* strengthen  v（使）变强，加强；使更坚固；增强，改善

muscle

* n肌肉；体力，力气；实力，影响力

enforce

* v强行实施，强制执行；强迫，迫使
* to enforce federal immigration law

compel

* v强迫，迫使，使必须
* to compel corporate boards to maintain a cert proportion of women
* compelling adj很有说服力的；引人入胜的，扣人心弦的

impel

* v促使，驱使；推进，推动
* to have impelled the change

propel

* v推进，推动；驱动；驱使，迫使

impose

* v强制推行，强制实行；把（信仰或生活方式）强加于，迫使

oblige

* v(因法律、义务等)迫使，强迫；帮忙，效劳
* to not oblige anyone to stop tracking
* obligatory adj（因法律、规定等）必须履行的，有义务的，强制性的

obligation

* adj. 必须履行的，有义务的；强制性的
* obligation. n义务，职责，责任

limit

* n限制，限度，极限；限量，限额；界限，范围
* v限制，限定
* to set strict limits on advertising
* limitation n限制，限定；【局限性】局限性，不足之处
* limited adj 有限的；（公司）有限责任的

restrict

* v限制，控制（大小、数量或范围）；限制，束缚，妨碍（行动或活动）
* to restrict advertising of products high in fat
* restriction. n限制，约束，规定；制约因素
* restrictive adj 限制性的；约束性的

confine

* v把……局限于，把……限制于；关押，监禁，禁闭；使离不开
* confinement n监禁，禁闭

curb

* v./n 控制；限制，约束；抑制
* the use of privacy law to curb the tech giants

constrain

* v限制，约束，束缚；阻止，妨碍
* constraint n限制，约束，束缚

bound

* adj 肯定会的，很有可能的；受束缚的，受约束的路；有义务的；准备前往……的，开往……的
* n跳跃，跳；【-s】(法律或社会的)界限，限度，极限
* v跳跃着前进；形成……的边界
* boundary n边界线，边界；限度，界限，极限

boundary

* boundary n 分界线，边界；限度，界限，极限

border

* n国界；边界；边境地区
* v与……接壤，与……毗邻

confines

* n[复]范围；界限；边界

link

* n联系，关联；关系，纽带；链接
* v有联系，有关联；使联系，使相关联；把……连接起来；说明……和……有联系

* linkage  n联系，关联；连接，接合

bond

* n纽带，联系，关系；公债，债券；契约，合约；结合，粘合；【-s】枷锁，桎梏

* v建立紧密联系，团结；粘合，结合
* bondage n束缚，限制；奴役
* goverment bonds 国债
* affectional bond

tie

* v系，扎，捆；得分相同，打成平局；连接，联合，使紧密联系；束缚，约束，限制
* n领带；不分胜负，平局；纽带，关系，联系

relate

* v相联系，有关系；使有联系，把……联系起来；产生共鸣，认同；叙述，讲述
* to figure out how you relate to your work
* relation n关联；亲戚，亲属；关系，联系，交往
* relationship n关系，联系，关联；恋爱关系；亲属关系

connect

* v使连接，相连；把……联系起来，由……联想到；与……建立良好关系，相处；为……接通（电话）；（运输工具）联运，衔接
* to prompt humans to connect with one another
* connection n联系，关联；连接，接通；连接物；【-s】人际关系，人脉；【-s】亲戚
* connectivity n(电脑、程序、设备、系统等的)连接性能

associate

* v联系，联想；把……联系在一起
* n朋友，同事；伙伴
* adj 副的；准的；非正式的
* an associate professor
* 派生association n协会，社团；关系，关联，交往；联系；联想

affiliate

* v使并入，使隶属；使紧密联系
* n附属机构，分支机构；分会
* affiliation n联系，从属关系，隶属关系

correlate

* v相互关联，相关
* position
* n位置，方位，地点；处境，状况；地位，身份，等级；职位，职务；安置方式，姿势；态度，立场
* v安放，放置；使驻扎

location

* 地点，位置；外景拍摄地；定位

site

* n地点，位置；建筑工地；地点，现场；网站

* ar
* archaeological sites 考古地点
* on site 在现场

setting

* n位置，环境；情节背景；调控装置

posture

* n姿态，姿势；态度，立场

stance

* （公开表明的）观点，立场，看法；站姿

attitude

* 态度，看法，心态

angle

* n角，角度；视角；（看问题的）角度，立场

pose

* v造成，引起，产生；提出；摆好姿势；提出问题；假装，冒充；装腔作势
* n姿势；装腔作势

post

* n职位，职务；邮政，邮递；邮件；岗位，哨所；柱，桩，杆；网站上公布的信息，帖子
* v邮政；张贴，公布；派驻，使驻守；发布
* prefix [post-] 后，以后

present

* adj 现在的，目前的；出席的，在场的；存在的
* n 目前，现在；礼物，赠品
* v[pri'zent] 颁发，授予，赠送；使发生（存在），引起，造成；描述，展现；提出，提交（观点、计划等）；出示；上演（广播）；主持；介绍，引荐
* presence n出席，到场；存在，出现
* presentation n颁发，授予；介绍；陈述，说明；出示；展现，呈现；演出
* presently adv 目前，此刻；不久，马上

current

* adj 现时的，当前的；现行的
* n 水流，气流，电流；思潮，潮流
* currency n通货，货币；通用，流行，流通

contemporary

* adj 当代的，现代的；同时期的，同时代的
* n同时代的人；同龄人，同悲

modern

* adj近代的，现代的；现代化的，新式的；新潮的，时髦的
* modernize v使现代化
* modernizator n现代化；现代化事物

grant

* n（政府）拨款，补助金
* v （指官方的）同意，给予，准予，授予；（表达相反的意思之前表示让步）承认，同意
* federal research grants
* take ……for granted 认为……是理所当然的；对……不予重视

confer

* v商讨，商议，协商；授予
* 派生 n会议；讨论会，商讨会
* discuss v商讨，讨论，谈论

accord

* n协议，条约；一致，符合
* v给予，赠予，授予（权利、地位、某种待遇）；（与……一致，符合）
* accordingly. adv因此，所以；照着，相应地
* accordance n [in ～with] 按照，依据
* in accord with:与……一致（或相符合）

donate

* 捐赠，捐献（尤指钱）；献（血）；捐献（器官）
* to donate to the good causes
* donation n.捐赠物；捐赠   donor n.捐赠者；献血者；捐献器官

submit

* v提交，递呈（文件、建议等);顺从，屈服，不得已接受；认为，主张
* to submit short sketches to obscure magazines
* submission. n顺从，屈服，不得已接受；提交（物），呈递；看法，意见

introduction

* n引言，序言，开场白；引进，推行；介绍，引见；初级读物，入门课程
* introductory adj序言的，引导，介绍性；入门的，初步的

range

* n一些列，（数量、种类等变化的）范围，幅度；系列商品；山脉；射程；生长区，分布区
* v（数量、种类等在一定的范围内）变化，变动；设计，论及，涵盖；衍及；延伸，绵亘；漫游，闲逛

array

* n一些列，一批，大量，大群
* v（美观地）布置，排列

field

* n田地，田野；领域，范围；现场，实地；运动场；行业；场
* v回答，处理

province

* n省；范围，领域；职责范围；
* [-s]外省，外地

span

* n一段时间；长度，宽度，跨度；范围，包括的种类
* v持续，贯穿；包括，涵盖

sphere

* n球，球状物；范围，领域
* spherical  adj球状的；球形的

spectrum

* n范围，幅度，系列，各层次；光谱；声谱；波谱；频谱

horizon

* n地平线；[-s]范围，界限，眼界

vary

* v相异，不同，有别；变化，变更，改变

* variation n变化，变动；变种，变体
* variable  adj 多变的；反复无的  n变量
* variant   n变体；变种
* various adj 各种不同的；各种各样的
* variety  n多样化，变化；不同种类，不同品种；变种，变体；综艺节目

fluctuate

* v波动，上下变动，起伏

wander

* v漫步，闲逛，徘徊；迷路；不集中，走神；离题；头脑糊涂；移动移去；蜿蜒曲折
* n漫步，闲逛，溜达

sense

* n感官，感觉官能；感觉，意识；理解力，判断力；理智，明智，良好的判断；意义，含义；[-s]健全的心智，理智
* v感觉到；意识到
* sensible adj 明智的，合理的；切合实际的；意识到，觉察到的

wisdom

* n智慧，明智，才华；知识，学问
* conventional wisdom

sanity

* n精神健全，神志正常；明智，理智

mind

* n介意，大脑；思考能力，思维；聪明人，有才智的人；心思；理智，健全的心智；记忆力
* v介意，在乎；当心，注意

intelligence

* n智力，智慧；理解力；聪颖，聪明；智能；情报，情报人员
* artificial intelligence
* intelligent adj 有智慧的，聪明的；理解能力强的；智能的
* intelligible adj明白易懂的

wit



* n幽默风趣；说话风趣的人；[-s]理解力，头脑，智力
* witty adj 说话风趣；妙趣横生

stress

* n压力，紧张；强调，重要性；重音，重读
* v强调，着重；紧张，焦虑，担心；重读
* stressful  adj压力大的，紧张的

pressure

* n挤压；压力，压强；气压；要求，呼吁；心理压力，紧张
* v强迫；施加压力

tension

* n紧张，焦虑，焦急；紧张关系，紧张局势；张力，拉力

strain

* n压力，紧张；压力，拉力，张力，作用力；损伤，拉伤，扭伤；品系，品种；个性特点，性格倾向，秉性
* v拉伤，扭伤，损伤；过度使用，使不堪承受；尽力，竭力

emphasis

* n重点，重要性，强调；重音，重读
* emphasize v强调，重视；使突出，使明显

highlight

* v使突出；强调
* n最有趣（或最精彩、最重要）的部分

underline

* v强调，突出；在……下画线

surprise

* n意向不到的事；惊奇，惊讶；令人惊奇的事物

amaze

* v使大为惊奇，使惊愕
* 派生amazing  adj令人惊诧的，惊人的；令人惊喜的

astonish

* v使吃惊；使惊讶
* astonishment. n惊愕；惊讶   astonishing  adj 令人惊讶的，惊人的

shock

* n令人震惊的事；惊愕，震惊；休克；触电，电击；冲击，剧烈震动；愤怒，生气，不快
* v震惊，惊愕；愤怒，生气，不快
* sticker shock价格震惊
* an electric shock

stun

* v使震惊，使惊讶
* stunning adj极漂亮的，极迷人的；令人惊奇的，令人震惊的

wonder

* v疑惑，想知道；非常惊讶，感到诧异；（用于语句，使某一请求更加正式和礼貌）不知能否……
* n惊讶，惊叹；奇迹，奇观，奇事

stagger

* v蹒跚，摇摇晃晃地走；使震惊，使大吃一惊
* n蹒跚
* staggering adj 令人震惊的；令人难以置信的

awe

* n敬畏；惊奇，惊叹
* v是敬畏；是使惊叹
* awful  adj 糟糕的，恶劣的；讨厌的；极大的，很多；骇人听闻的，可怕的
* adv极其；非常
* awesome adj 令人敬畏的，令人惊叹的；很好的，了不起的

avoid

* v避免，防止；避开，逃避

avert

* v避免，防止；转移
* aversion n厌恶，反感；讨厌的人（或事物）

escape

* v逃走，逃跑；逃脱，摆脱；避开，避免；被忘掉，未被注意
* to escape the context of our unique life experience
* escapism. n避免现实的消遣活动

refrain

* v克制；避免；忍住
* n反复句，副歌；一再重复的话

evade

* v逃避，躲开；回避，避开；逃避，规避
* to effectively evade the flaws of the social cure
* evasive adj 回避的，避而不谈的；规避的
* evasion n回避；逃避

cost

* n价格，费用，成本；代价，牺牲，付出
* v需付费，价钱为；使付出代价，使牺牲
* costly adj昂贵的，价格高的；造成严重损失的，代价大的
* at all cost(s) 不惜任何代价；无论如何

price

* n价格，价钱；代价
* v给……定价
* share price
* priceless adj 极其贵重的，无价的

expense

* n花费；费用；花钱的东西，开销
* at the expense of

expenditure

* n政府开支，花费；耗费，花费

charge

* v收费，要价，开价；指控，公开指责，谴责；充电
* n收费，费用，价格；指控，控告；指责，谴责；主管，负责；电量，电荷

fetch

* v拿来，取回；请来；售得，卖得（……价钱）

event

* n事情，事件；项目；活动

incident

* n事件；摩擦，冲突
* incidental adj 附带的，伴随的；伴随而来的，免不了的
* incidentally. adv顺便提一下；附带地，伴随地

occasion

* n时刻，时候；特殊场合，重大活动；时机

episode

* n事件，一连串事件，一段经历；一集，一节

campaign

* n活动，运动；战役
