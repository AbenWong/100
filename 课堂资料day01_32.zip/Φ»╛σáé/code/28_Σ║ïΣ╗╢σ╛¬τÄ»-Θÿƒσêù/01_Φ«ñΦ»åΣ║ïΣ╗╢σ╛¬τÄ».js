
console.log("script start")

// 业务代码
setTimeout(function() {

}, 1000)

console.log("后续代码~")


console.log("script end")
