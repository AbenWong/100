console.log(window.location)

// 当前的完整的url地址
console.log(location.href)

// 协议protocol
console.log(location.protocol)

// 几个方法
// location.assign("http://www.baidu.com")
// location.href = "http://www.baidu.com"

// location.replace("http://www.baidu.com")
// location.reload(false)
