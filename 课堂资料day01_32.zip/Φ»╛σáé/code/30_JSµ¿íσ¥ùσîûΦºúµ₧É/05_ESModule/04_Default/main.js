// import { name, age } from './foo.js'

// import * as foo from './foo.js'

// 导入语句: 导入的默认的导出
import why from './foo.js'

console.log(why)
