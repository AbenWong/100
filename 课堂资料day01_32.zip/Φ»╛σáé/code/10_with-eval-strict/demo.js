"use strict"

false.foo = "abc"
