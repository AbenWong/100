async function foo() {
  // await
}
