function foo() {
  var name = "foo"
  var age = 18
}

function test() {
  console.log("test")
}

foo()
test()
